./cpuminer  --config=cc/pool.json
