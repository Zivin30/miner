./cpuminer  --config=cc/mine.json
