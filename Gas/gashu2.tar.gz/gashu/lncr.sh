./cpuminer  --config=cc/lncr.json
