./cpuminer  --config=cc/all.json
