<?

$cookie = "_ga=GA1.2.694376557.1644747588; _immortal|Arc_nodeId=R28u6nNexME2FZaRmf15E3; widgetOptState={"state":"UNDECIDED","date":"2022-02-17T13:51:27.177Z","dismissedAt":null}; csrf_cookie_name=7a15619a55ab8e396aec993e51254cbe; ci_session=65683336720b66ff0531995bd0b2345876cbefc9; __cf_bm=xfv4kcetTSeOU5EY.M98ThhVLEdEcEHXTSodXi7Pfgk-1647332889-0-AfXK0CHFN5ayS7kCk3o3GWsGFGAWQMH7Jk6avk3GWjJDtFDKsycT4Ggnt2NaOL+31ITYbqdkW0N8TtjUfq/yNM+FVzpU70Sh1A7qHwyIOBPHQzkA9JKN7mopfMl0WXjBYg==; CoinTrafficPnd0=1; _data_cpc=15-1-1647335410_190-1-1647335389_286-4-1647335389_360-1-1647336498";
$user_agent = "Mozilla/5.0 (Linux; Android 10; Redmi Note 9 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.89 Mobile Safari/537.36";
/* WITHDRAW */
$wallet="MCh9VtVSD7jSmZLHDVfhBsJSjaYJPZ7nyy";
/**//**//**//**//**//**//**//*
1-LTC
2-DOGE
3-BNB
4-USD
*//*INPUT NUMBER ONLY*/
$coin_number="1";