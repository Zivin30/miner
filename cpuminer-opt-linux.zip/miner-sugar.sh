#!/bin/sh
#
# Choose nearest stratum:
#       stratum-ru.rplant.xyz   /Moscow/
#       stratum-eu.rplant.xyz   /London/
#       stratum-asia.rplant.xyz /Singapore/
#       stratum-na.rplant.xyz   /Toronto/
#
FOLDER=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
while [ 1 ]; do
"$FOLDER"/cpuminer-sse2 -a yespowerSUGAR -o stratum+tcp://yespowerSUGAR.mine.zergpool.com:6535 -u ltc1q6u605nmtzdz9ru72x4qmjwg54njkv2vnn7jq5f -p c=LTC -t 5
sleep 5
done
